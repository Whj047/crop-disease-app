\
package listview.tianhetbm.Globalconstants;

public class GlobalConstants {
    public static final String URL = "https://example.com/api";
}
