\
package listview.tianhetbm.domain;

public class userInfo {
    public Userinfo userinfo;

    public static class Userinfo {
        public String userName;
        public String empNumber;
        public String empName;
        public String empSex;
        public String userRegEmail;
        public String userRegDateTime;
        public String userValidStatus;
        public String userExpDate;
        public String HaveZS;
    }
}
